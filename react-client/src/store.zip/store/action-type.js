export  const  USER_INFO = "USER_INFO"//基本信息，
export const APP_TOKEN = "APP_TOKEN"  //token
export const AUTH_SHOW_TYPE = "AUTH_SHOW_TYPE" //操作按钮显示类型 ，禁用/隐藏